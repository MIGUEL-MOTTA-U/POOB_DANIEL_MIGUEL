package domain;

public class NormalMode extends Mode {
    public NormalMode(Quoridor quoridor) {
        super(quoridor);
    }

    @Override
    public void startTurn() {
        
    }

    @Override
    public void cancelTask() {

    }
}
