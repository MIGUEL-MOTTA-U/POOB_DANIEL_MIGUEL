package domain;

import java.awt.Color;

public class LongWall extends Wall {
    public LongWall(Color color) {
        super(color);
    }

    @Override
    public void act() {
        
    }
}
