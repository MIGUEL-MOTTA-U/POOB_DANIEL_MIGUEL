package domain;

    public class NormalSquare extends Square {
    public NormalSquare(int row, int column, Board board) throws QuoriPOOBException {
        super(row, column, board);
    }
}
