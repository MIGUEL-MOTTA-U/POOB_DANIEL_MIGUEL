package domain;

import java.awt.Color;

public class Allied extends Wall {
    public Allied(Color color) {
        super(color);
    }
}
