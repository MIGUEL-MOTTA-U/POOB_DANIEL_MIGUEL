package domain;

public class DoubleTurn extends Square{
    public DoubleTurn(int row, int column, Board board) throws QuoriPOOBException {
        super(row, column, board);
    }

}
