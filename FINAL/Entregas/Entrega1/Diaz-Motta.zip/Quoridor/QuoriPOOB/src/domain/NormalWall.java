package domain;

import java.awt.Color;

public class NormalWall extends Wall {
    public NormalWall(Color color) {
        super(color);
    }
}
