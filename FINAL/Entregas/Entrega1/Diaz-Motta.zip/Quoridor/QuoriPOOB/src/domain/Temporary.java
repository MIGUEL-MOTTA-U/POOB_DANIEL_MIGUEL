package domain;

import java.awt.Color;

public class Temporary extends Wall {
    private int turn;

    public Temporary(Color color) {
        super(color);
    }
}
