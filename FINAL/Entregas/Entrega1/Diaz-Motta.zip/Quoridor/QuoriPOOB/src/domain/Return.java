package domain;

public class Return extends Square{
    public Return(int row, int column, Board board) throws QuoriPOOBException {
        super(row, column, board);
    }
}
