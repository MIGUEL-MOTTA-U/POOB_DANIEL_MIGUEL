package domain;

public class Token {

}
