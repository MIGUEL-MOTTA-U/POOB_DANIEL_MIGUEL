package domain;

import java.awt.*;

public abstract class Machine extends Player {
    public Machine(String name, Color color) {
        super(name, color);
    }
}
