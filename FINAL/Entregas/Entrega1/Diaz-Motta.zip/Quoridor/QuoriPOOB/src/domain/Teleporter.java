package domain;

public class Teleporter extends Square {
    public Teleporter(int row, int column, Board board) throws QuoriPOOBException {
        super(row, column, board);
    }
}
