package domain;

import java.awt.Color;

public class Advanced extends Machine {
    public Advanced(String name, Color color) {
        super(name, color);
    }

    @Override
    public void moveToken(String direction) throws QuoriPOOBException{

    }

    @Override
    public void addWallToBoard(String type, int initialRow, int initialColumn, String squareSide) throws QuoriPOOBException {

    }
}
